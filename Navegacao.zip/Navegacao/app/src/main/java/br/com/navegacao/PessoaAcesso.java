package br.com.navegacao;

public class PessoaAcesso {

    private long id;
    private String usuario;
    private String senha;
    private String telefone;
    private String email;
    private String name;
    private String age;
    private String occupation;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }


    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public PessoaAcesso(){

    }

    //CONSTRUTOR PESSOA
    public PessoaAcesso(String name, String age, String occupation) {
        this.name = name;
        this.age = age;
        this.occupation = occupation;
    }
}
